const express = require('express');
const { db } = require('../db');
const { verifyToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.get('/', verifyToken, requireAdmin, (req, res) => {
  const rows = db.all('SELECT c.*, u.name AS submitter FROM cruelty_reports c LEFT JOIN users u ON c.user_id = u.id ORDER BY c.created_at DESC');
  res.json(rows);
});

router.post('/', verifyToken, (req, res) => {
  const { location, incident_description, severity, lat, lng } = req.body;
  if (!location || !incident_description) {
    return res.status(400).json({ error: 'Location and incident description are required' });
  }
  const result = db.run(
    'INSERT INTO cruelty_reports (user_id, location, incident_description, severity, lat, lng) VALUES (?, ?, ?, ?, ?, ?)',
    req.user.id, location, incident_description, severity || 'medium', lat || null, lng || null
  );
  const row = db.get('SELECT * FROM cruelty_reports WHERE id = ?', result.lastInsertRowid);
  res.status(201).json(row);
});

router.put('/:id/status', verifyToken, requireAdmin, (req, res) => {
  const { status } = req.body;
  if (!['pending', 'investigating', 'resolved'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }
  db.run('UPDATE cruelty_reports SET status = ? WHERE id = ?', status, req.params.id);
  const row = db.get('SELECT * FROM cruelty_reports WHERE id = ?', req.params.id);
  res.json(row);
});

module.exports = router;
